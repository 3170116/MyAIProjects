/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;

/**
 *
 * @author Jimis
 */
class Lesson {
    private String name;
    private String cl;
    private String id;
    private String hours;
    private String[] teachers;

    public Lesson(String name, String cl, String id, String hours) {
        this.name = name;
        this.cl = cl;
        this.id = id;
        this.hours = hours;
        this.teachers = null;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCl() {
        return cl;
    }

    public void setCl(String cl) {
        this.cl = cl;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getHours() {
        return hours;
    }

    public void setHours(String hours) {
        this.hours = hours;
    }

    public String[] getTeachers() {
        return teachers;
    }

    public void setTeachers(String[] teachers) {
        this.teachers = teachers;
    }
    
    @Override
    public String toString() {
        return name + " " + cl + " Γυμνασίου";
    }

    public boolean hasTeacher(String id) {
        for (String tId: this.teachers) {
            if (tId.equals(id)) return true;
        }
        return false;
    }
}
