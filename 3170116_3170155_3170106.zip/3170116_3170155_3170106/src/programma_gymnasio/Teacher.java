/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;

/**
 *
 * @author Jimis
 */
public class Teacher {
    
    private String name;
    private String id;
    private String[] lessons;
    private String maxDailyHours;
    private String maxWeekHours;

    public Teacher(String name, String id, String[] lessons, String maxDailyHours, String maxWeekHours) {
        this.name = name;
        this.id = id;
        this.lessons = lessons;
        this.maxDailyHours = maxDailyHours;
        this.maxWeekHours = maxWeekHours;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String[] getLessons() {
        return lessons;
    }

    public void setLessons(String[] lessons) {
        this.lessons = lessons;
    }

    public String getMaxDailyHours() {
        return maxDailyHours;
    }

    public void setMaxDailyHours(String maxDailyHours) {
        this.maxDailyHours = maxDailyHours;
    }

    public String getMaxWeekHours() {
        return maxWeekHours;
    }

    public void setMaxWeekHours(String maxWeekHours) {
        this.maxWeekHours = maxWeekHours;
    }

   

    @Override
    public String toString() {
        return "Teacher{" + "name=" + name + ", id=" + id + ", lessons=" + lessons + ", maxHours=" + this.maxWeekHours + '}';
    }
    
    
    public boolean contains(String lessonId) {
        for (String id: this.lessons)
            if (id.equals(lessonId)) return true;
        return false;
    }
}
