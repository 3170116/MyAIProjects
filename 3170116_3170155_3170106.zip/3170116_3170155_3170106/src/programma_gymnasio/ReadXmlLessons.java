/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Jimis
 */
class ReadXmlLessons {
    
    public ArrayList<Lesson> readFile(String data){
        File f = null;
	BufferedReader reader = null;
        String line=null;
	ArrayList<Lesson> list =new ArrayList<Lesson>();
		    
	try {
	    f = new File(data);
	} catch (NullPointerException e) {
	    System.err.println("File not found.");
	}
				
	    try {
	        reader = new BufferedReader(new FileReader(f));
	    } catch (FileNotFoundException e) {
                System.err.println("Error opening file!");
	    }
			
	    try {
		    String id="",name="",cl="",hours=""; 
		   
		    line= reader.readLine();
		    while(line!=null){
			if(line.trim().equals("<Lesson>")){
                            while(!line.trim().equals("</Lesson>")){
				line=reader.readLine();
                                
				if(line.trim().startsWith("<lesson_name>")){
                                    int start = line.indexOf("<lesson_name>");
                                    int end = line.indexOf("</lesson_name>");
                                    name = line.substring(start + 13,end);
				}

				if(line.trim().startsWith("<lesson_id>")){
                                    int start = line.indexOf("<lesson_id>");
                                    int end = line.indexOf("</lesson_id>");
                                    id = line.substring(start + 11,end);
				}

				if(line.trim().startsWith("<lesson_class>")){
                                    int start = line.indexOf("<lesson_class>");
                                    int end = line.indexOf("</lesson_class>");
                                    cl = line.substring(start + 14,end);
				}

				if(line.trim().startsWith("<hourspweek>")){
                                    int start = line.indexOf("<hourspweek>");
                                    int end = line.indexOf("</hourspweek>");
                                    hours = line.substring(start + 12,end);
				}
				   
                            }
                            
                            if (Integer.parseInt(hours) > 0)
                                list.add(new Lesson(name,cl,id,Integer.parseInt(hours) + ""));
			}
			line=reader.readLine();   
		    }
		   
            } catch (IOException e) {
	        System.out.println("Error reading line ...");
	    } 
		   
	try {
	    reader.close();
	} catch (IOException e) {
	    System.err.println("Error closing file.");
	}

	return list;
    }
}
