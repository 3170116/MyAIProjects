/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Jimis
 */
public class ReadXmlTeachers {
    
    public ArrayList<Teacher> readFile(String data){
        File f = null;
	BufferedReader reader = null;
        String line=null;
	ArrayList<Teacher> list =new ArrayList<Teacher>();
		    
	try {
	    f = new File(data);
	} catch (NullPointerException e) {
	    System.err.println("File not found.");
	}
				
	    try {
	        reader = new BufferedReader(new FileReader(f));
	    } catch (FileNotFoundException e) {
                System.err.println("Error opening file!");
	    }
			
	    try {
		    String id="",name="",dailyHours="",weekHours = ""; 
                    ArrayList<String> lessonsIds = new ArrayList<String>();
		   
		    line= reader.readLine();
		    while(line != null){
			if(line.trim().startsWith("<Teacher>")){
                            while(!line.trim().equals("</Teacher>")){
				line=reader.readLine();
                                
				if(line.trim().startsWith("<name>")){
                                    int start = line.indexOf("<name>");
                                    int end = line.indexOf("</name>");
                                    name = line.substring(start + 6,end);
				}

				if(line.trim().startsWith("<id>")){
                                    int start = line.indexOf("<id>");
                                    int end = line.indexOf("</id>");
                                    id = line.substring(start + 4,end);
				}

				if(line.trim().startsWith("<lesson_id>")){
                                    int start = line.indexOf("<lesson_id>");
                                    int end = line.indexOf("</lesson_id>");
                                    lessonsIds.add(line.substring(start + 11,end));
				}

				if(line.trim().startsWith("<max_daily_hours>")){
                                    int start = line.indexOf("<max_daily_hours>");
                                    int end = line.indexOf("</max_daily_hours>");
                                    dailyHours = line.substring(start + 17,end);
				}
                                
                                if(line.trim().startsWith("<max_per_week_hours>")){
                                    int start = line.indexOf("<max_per_week_hours>");
                                    int end = line.indexOf("</max_per_week_hours>");
                                    weekHours = line.substring(start + 20,end);
				}
				   
                            }
                            String[] lessonsArray = new String[lessonsIds.size()];
                            list.add(new Teacher(name,id,lessonsIds.toArray(lessonsArray),dailyHours,weekHours));
			}
                        lessonsIds = new ArrayList<String>();
			line=reader.readLine();   
		    }
		   
            } catch (IOException e) {
	        System.out.println("Error reading line ...");
	    } 
		   
	try {
	    reader.close();
	} catch (IOException e) {
	    System.err.println("Error closing file.");
	}

	return list;
    }
}
