/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;

/**
 *
 * @author Jimis
 */

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.logging.Level;
import java.util.logging.Logger;

class State implements Comparable<State> {
    
    private ArrayList<Lesson> lessons_list;
    private ArrayList<Teacher>teachers_list;
    private HashMap<String,Lesson> mapLessons;
    private HashMap<String ,Teacher> mapTeachers;
    private Pair[] randomProgramma;
    
    private int score;
    
    private final int LESSONS_AT_THE_SAME_HOUR = 10;
    private final int THREE_HOURS_TEACHING = 1000;
    private final int MAX_DAILY_HOURS = 10000;
    private final int MAX_WEEK_HOURS = 10;
    private final int DEVIATION = 1;

    public State(ArrayList<Lesson> lessons_list, ArrayList<Teacher> teachers_list, HashMap<String, Lesson> mapLessons, HashMap<String, Teacher> mapTeachers, Pair[] randomProgramma) {
        this.lessons_list = lessons_list;
        this.teachers_list = teachers_list;
        this.mapLessons = mapLessons;
        this.mapTeachers = mapTeachers;
        this.randomProgramma = randomProgramma;
        this.score = this.calculateScore();
    }
    
    public State(ArrayList<Lesson> lessons_list, ArrayList<Teacher> teachers_list, HashMap<String, Lesson> mapLessons, HashMap<String, Teacher> mapTeachers) {
        this.lessons_list = lessons_list;
        this.teachers_list = teachers_list;
        this.mapLessons = mapLessons;
        this.mapTeachers = mapTeachers;
        
        this.randomProgramma = new Pair[9*Programma_Gymnasio.NUMBER_OF_HOURS];
        for (int classroom = 0; classroom < 9; classroom++) {
            for (int hour = 0; hour < 7; hour++) {//request 3 is done
                for (int day = 0; day < 5; day++) {
                    Collections.shuffle(lessons_list);//request 4 is done
                    for (Lesson lesson: lessons_list) {
                        boolean done = false;
                        String lId = lesson.getId().substring(0,1);
                        if ((lId.equals("A") && classroom < 3) || (lId.equals("B") && classroom >= 3 && classroom < 6) || (lId.equals("C") && classroom >= 6)) {
                            if (randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + 8*day + hour] == null) {
                                //first chech if the lesson has completele taught at this class
                                int hoursTaught = 0;
                                for (int prevHour = 0; prevHour < Programma_Gymnasio.NUMBER_OF_HOURS; prevHour++) {
                                    if (prevHour == 7 || prevHour == 15 || prevHour == 23 || prevHour == 31) continue;
                                    if (randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + prevHour] == null) continue;
                                    
                                    if (lesson.getId().equals(randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + prevHour].getLessonId())) {
                                        hoursTaught++;
                                    }
                                }   
                                if (hoursTaught < Integer.parseInt(lesson.getHours())) {
                                    randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + 8*day + hour] = new Pair(lesson.getId(),lesson.getTeachers());
                                    done = true;
                                }            
                            }
                            if (done) break;
                        }
                    }
                }
            }
        }
        
        this.score = this.calculateScore();
    }

    public ArrayList<Lesson> getLessons_list() {
        return lessons_list;
    }

    public void setLessons_list(ArrayList<Lesson> lessons_list) {
        this.lessons_list = lessons_list;
    }

    public ArrayList<Teacher> getTeachers_list() {
        return teachers_list;
    }

    public void setTeachers_list(ArrayList<Teacher> teachers_list) {
        this.teachers_list = teachers_list;
    }

    public HashMap<String, Lesson> getMapLessons() {
        return mapLessons;
    }

    public void setMapLessons(HashMap<String, Lesson> mapLessons) {
        this.mapLessons = mapLessons;
    }

    public HashMap<String, Teacher> getMapTeachers() {
        return mapTeachers;
    }

    public void setMapTeachers(HashMap<String, Teacher> mapTeachers) {
        this.mapTeachers = mapTeachers;
    }

    public Pair[] getRandomProgramma() {
        return randomProgramma;
    }

    public void setRandomProgramma(Pair[] randomProgramma) {
        this.randomProgramma = randomProgramma;
    }

    public int getScore() {
        return score;
    }
    
    
    public void print() {
        for (int hour = 0; hour < Programma_Gymnasio.NUMBER_OF_HOURS; hour++) {
            for (int classroom = 0; classroom < 9; classroom++) {
                if (hour == 7 || hour == 15 || hour == 23 || hour == 31) continue;
                String lessonId = (randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour] != null) ? randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour].getLessonId() : null;
                String teacherId = (randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour] != null) ? randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour].getTeacherId(): null;
                System.out.print(lessonId + "/" + teacherId + " ");
            }
            System.out.println();
        }
    }
    
    public void writeSchedule() {
        File f = null;
        BufferedWriter writer = null;
        
        f = new File(Programma_Gymnasio.PATH + "Schedule.txt");
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f),"utf-8"));
        } catch (IOException ex) {
            Logger.getLogger(State.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        String[] days = {"Monday","Tuesday","Wednesday","Thursday","Friday"};
        String[] classrooms = {"A1","A2","A3","B1","B2","B3","C1","C2","C3"};
        for (int day = 0; day < 5; day++) {
            try {
                writer.write("                      " + days[day] + "\n\n");
                for (int hour = 0; hour < 7; hour++) {
                    writer.write("Hour " + (hour + 1) + ":\n\n");
                    for (int classroom = 0; classroom < 9; classroom++) {
                        Pair pair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour];
                        if (pair != null)
                            writer.write("Classroom " + classrooms[classroom] + " has " + 
                                    this.mapLessons.get(pair.getLessonId()).getName() + 
                                    " with teacher " + this.mapTeachers.get(pair.getTeacherId()).getName() + "\n");
                    }
                    writer.write("\n");
                }
            } catch (IOException ex) {
                Logger.getLogger(State.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        try {
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(State.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public boolean isOk() {
        return this.score == 0;
    }
    
    public State[] getChildren(int hour) {
        ArrayList<State> children = new ArrayList<State>();
        
        //find each hour which is not ok
        if (hour == 7 || hour == 15 || hour == 23 || hour == 31) return null;
            //if (this.score(hour) > 0) {
                
            //find every teacher who is teaching more than 1 lesson and replace with all others possible
            ArrayList<String> teachers = this.getTeachers(hour);
            for (String teacher: teachers) {
                int count = 0;
                for (int classroom = 0; classroom < 9; classroom++) {
                    Pair pair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour];
                    if (pair == null) continue;
                    if (pair.getTeacherId().equals(teacher)) count++;
                }
                    
                if (count > 1) {
                    //every swap will be a new state
                    for (int classroom = 0; classroom < 9; classroom++) {
                        for (int newHour = 0; newHour < Programma_Gymnasio.NUMBER_OF_HOURS; newHour++) {
                            if (newHour == 7 || newHour == 15 || newHour == 23 || newHour == 31) continue;
                            //lessonId is the id of the lesson which the teacher MAY teaches
                            Pair pair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour];
                            //newLessonId is a possible to swap
                            Pair newPair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + newHour];
                                
                            if (pair == null && newPair == null) continue;
                                
                            if (pair == null && newPair != null) {
                                //check if is the last hour of day
                                if (newHour == 6 || newHour == 14 || newHour == 22 || newHour == 30) {//request 1 is done
                                    Pair[] newProgramma = new Pair[9*Programma_Gymnasio.NUMBER_OF_HOURS];
                                    for (int i = 0; i < 9*Programma_Gymnasio.NUMBER_OF_HOURS; ++i) {
                                        newProgramma[i] = this.randomProgramma[i];
                                    }

                                    newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour] = newPair.copy();
                                    newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + newHour] = null;

                                    State state = new State(lessons_list,teachers_list,mapLessons,mapTeachers,newProgramma);
                                    children.add(state);
                                }
                            }
                                
                            if (pair != null && newPair == null) {
                                //check if is the last hour of day
                                if (hour == 6 || hour == 14 || hour == 22 || hour == 30) {//request 1 is done
                                    Pair[] newProgramma = new Pair[9*Programma_Gymnasio.NUMBER_OF_HOURS];
                                    for (int i = 0; i < 9*Programma_Gymnasio.NUMBER_OF_HOURS; ++i) {
                                        newProgramma[i] = this.randomProgramma[i];
                                    }

                                    newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour] = null;
                                    newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + newHour] = pair.copy();

                                    State state = new State(lessons_list,teachers_list,mapLessons,mapTeachers,newProgramma);
                                    children.add(state);
                                }
                            }
                                
                            if (pair != null && newPair != null && 
                                pair.getTeacherId().equals(teacher) && !newPair.getTeacherId().equals(teacher)) {
                                Pair[] newProgramma = new Pair[9*Programma_Gymnasio.NUMBER_OF_HOURS];
                                for (int i = 0; i < 9*Programma_Gymnasio.NUMBER_OF_HOURS; ++i) {
                                    newProgramma[i] = this.randomProgramma[i];
                                }
                                    
                                newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour] = newPair.copy();
                                newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + newHour] = pair;
                                    
                                State state = new State(lessons_list,teachers_list,mapLessons,mapTeachers,newProgramma);
                                children.add(state);
                            }
                        }
                    }
                }
            }
        
        //swap all possible teachers for each lesson
        for (int classroom = 0; classroom < 9; classroom++) {
            ArrayList<String> lessonsChecked = new ArrayList<String>();
            if (hour == 7 || hour == 15 || hour == 23 || hour == 31) continue;
                
            Pair pair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + hour];
            if (pair == null) continue;
                
            if (!lessonsChecked.contains(pair.getLessonId())) {
                lessonsChecked.add(pair.getLessonId());
                    
                for (String teacherId: pair.getTeachersIds()) {
                    if (teacherId.equals(pair.getTeacherId())) continue;
                        
                    Pair[] newProgramma = new Pair[9*Programma_Gymnasio.NUMBER_OF_HOURS];
                    for (int i = 0; i < 9*Programma_Gymnasio.NUMBER_OF_HOURS; ++i) {
                        newProgramma[i] = this.randomProgramma[i];
                    }
                        
                    for (int h = 0; h < Programma_Gymnasio.NUMBER_OF_HOURS; h++) {
                        Pair p = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + h];
                        if (p == null) continue;
                            
                        if (p.getLessonId().equals(pair.getLessonId())) {
                            newProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + h] = new Pair(pair.getLessonId(),teacherId,pair.getTeachersIds());
                        }
                    }
                        
                    State state = new State(lessons_list,teachers_list,mapLessons,mapTeachers,newProgramma);
                    children.add(state);
                }
            }
        }

        State[] result = new State[children.size()];
        for (int i = 0; i < children.size(); ++i) result[i] = children.get(i);
        return result;
    }
    
    public int  calculateScore() {
        //returns the total score
        //if score = 0 means that the schedule is ok
        //as score is decreasing means that the schedule is becoming better and better
        
        int s = 0;
        ArrayList<String> dailyTeachers = new ArrayList<String>();
        HashMap<String,Integer> dailyHoursForEachTeacher = new HashMap<String,Integer>();
        HashMap<String,Integer> totalHoursForEachTeacher = new HashMap<String,Integer>();
        for (int hour = 0; hour < Programma_Gymnasio.NUMBER_OF_HOURS; hour++) {
            if (hour == 7 || hour == 15 || hour == 23 || hour == 31) {
                //request 5 is done
                for (String teacher: dailyTeachers) {
                    int maxDailyHours = Integer.parseInt(this.mapTeachers.get(teacher).getMaxDailyHours());
                    if (maxDailyHours < dailyHoursForEachTeacher.get(teacher)) s += MAX_DAILY_HOURS*(dailyHoursForEachTeacher.get(teacher) - maxDailyHours);
                }
                dailyTeachers.clear();
                dailyHoursForEachTeacher.clear();
            } else {           
                ArrayList<String> currentTeachers = this.getTeachers(hour);
                for (String teacher: currentTeachers) {
                    //we count the number of lessons that teacher map.getKey() studied th
                    if (dailyHoursForEachTeacher.containsKey(teacher))
                        dailyHoursForEachTeacher.replace(teacher, dailyHoursForEachTeacher.get(teacher) + 1);
                    else
                        dailyHoursForEachTeacher.put(teacher,1);
                    
                    if (!dailyTeachers.contains(teacher)) dailyTeachers.add(teacher);
                    
                    
                    if (totalHoursForEachTeacher.containsKey(teacher))
                        totalHoursForEachTeacher.replace(teacher, totalHoursForEachTeacher.get(teacher) + 1);
                    else
                        totalHoursForEachTeacher.put(teacher,1);
                }
                s += this.score(hour);
            }
        }
        
        //chech if any teacher is teaching more hours than he can
        for (Entry<String, Integer> map: totalHoursForEachTeacher.entrySet()) {
            int maxWeekHours = Integer.parseInt(this.mapTeachers.get(map.getKey()).getMaxWeekHours());
            if (map.getValue() > maxWeekHours) s += MAX_WEEK_HOURS*(map.getValue() - maxWeekHours);
        }
        
        //check if there are common teachers whose hours difference is more than 5
        ArrayList<String> checkedTeachers = new ArrayList<String>();
        for (Entry<String, Integer> map: totalHoursForEachTeacher.entrySet()) {
            checkedTeachers.add(map.getKey());
            for (Entry<String, Integer> newMap: totalHoursForEachTeacher.entrySet()) {
                if (checkedTeachers.contains(newMap.getKey())) continue;
                
                if (!map.getKey().equals(newMap.getKey()) && Math.abs(map.getValue() - newMap.getValue()) > 5) {
                    //check if they have common subjects
                    int common = 0;
                    for (String lessonId: this.mapTeachers.get(map.getKey()).getLessons())
                        if (this.mapTeachers.get(newMap.getKey()).contains(lessonId)) common++;
                    
                    if (common > 2)
                        s += DEVIATION*Math.abs(map.getValue() - newMap.getValue());
                }
            }
        }

        return s;
    }
    
    
    private int score(int idx) {
        //returns the score of hour idx
        
        int s = 0;
        //we store the number of lessons that each teacher studies at hour idx 
        HashMap<String,Integer> hoursForEachTeacher = new HashMap<String,Integer>();
        for (int classroom = 0; classroom < 9; classroom++) {
            Pair pair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*classroom + idx];
            if (pair == null) continue;
            
            if (hoursForEachTeacher.containsKey(pair.getTeacherId()))
                hoursForEachTeacher.replace(pair.getTeacherId(), hoursForEachTeacher.get(pair.getTeacherId()) + 1);
            else
                hoursForEachTeacher.put(pair.getTeacherId(),1);
        }
        
        //if a teacher is teaching more than 2 lessons this hour the total score is increasing
        for (Entry<String, Integer> map: hoursForEachTeacher.entrySet()) {
            if (map.getValue() > 1) s += LESSONS_AT_THE_SAME_HOUR*(map.getValue() - 1);
        }
        
        for (Entry<String, Integer> map: hoursForEachTeacher.entrySet()) {
            int counter = 0;
            //we count the number of lessons that teacher map.getKey() studied the last 2 hours
            for (int prevHour = idx - 1; prevHour >= 0 && prevHour >= idx - 2; prevHour--) {
                if (prevHour == 7 || prevHour == 15 || prevHour == 23 || prevHour == 31) break;
                for (int room = 0; room < 9; room++) {
                    Pair prevLesson = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*room + prevHour];
                    if (prevLesson == null) continue;
                    if (prevLesson.getTeacherId().equals(map.getKey())) counter++;
                }
            }
            if (counter > 1) s += THREE_HOURS_TEACHING*(counter - 1);//request 2 is done
        }
        
        return s;
    }
    
    //returns the teachers who study at hour 'hour'
    private ArrayList<String> getTeachers(int hour) {
        ArrayList<String> result = new ArrayList<String>();
        for (int i = 0; i < 9; i++) {
            Pair pair = this.randomProgramma[Programma_Gymnasio.NUMBER_OF_HOURS*i + hour];
            if (pair == null) continue;
            String teacher = pair.getTeacherId();
            if (!result.contains(teacher))
               result.add(teacher);
        }
        return result;
    }
    
    @Override
    public int hashCode() {
        return this.score;
    }
    
    @Override
    public boolean equals(Object state) {
        for (int i = 0; i < Programma_Gymnasio.NUMBER_OF_HOURS; i++)
            if (this.randomProgramma[i] == null || ((State) state).getRandomProgramma()[i] == null ||
                    !this.randomProgramma[i].equals(((State) state).getRandomProgramma()[i])) return false;
        return true;
    }

    @Override
    public int compareTo(State o) {
        return this.score - o.getScore();
    }
}
