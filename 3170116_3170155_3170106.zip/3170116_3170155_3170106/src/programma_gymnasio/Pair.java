/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;

/**
 *
 * @author Jimis
 */
public class Pair {
    
    private String lessonId;
    private String teacherId;
    private String[] teachersIds;

    
    public Pair(String lessonId, String teacherId, String[] teachersIds) {
        this.lessonId = lessonId;
        this.teacherId = teacherId;
        this.teachersIds = teachersIds;
    }

    public Pair(String lessonId, String[] teachersIds) {
        this(lessonId,teachersIds[0],teachersIds);
    }


    public String getLessonId() {
        return lessonId;
    }

    public void setLessonId(String lessonId) {
        this.lessonId = lessonId;
    }

    public String getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(String teacherId) {
        this.teacherId = teacherId;
    }

    public String[] getTeachersIds() {
        return teachersIds;
    }

    public void setTeachersIds(String[] teachersIds) {
        this.teachersIds = teachersIds;
    }
    
    
    public Pair copy() {
        return new Pair(this.lessonId,this.teacherId,this.teachersIds);
    }
    
    @Override
    public boolean equals(Object p) {
        return this.lessonId.equals(((Pair) p).getLessonId()) && this.teacherId.equals(((Pair) p).getTeacherId());
    }

}
