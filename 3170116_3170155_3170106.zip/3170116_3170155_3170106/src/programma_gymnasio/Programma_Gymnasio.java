/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programma_gymnasio;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 *
 * @author Jimis
 */
class Programma_Gymnasio {

    //we actually have 5*7 hours but we use 4 columns with null
    //to signal the end of each day
    public static final int NUMBER_OF_HOURS = 39;
    public static final String PATH = "C:\\Users\\Jimis\\Documents\\NetBeansProjects\\3170116_3170155_3170106\\src\\programma_gymnasio\\";
    
    public static void main(String[] args) {
        long t1 = System.currentTimeMillis();
        
        ReadXmlLessons rLessons = new ReadXmlLessons();
        ReadXmlTeachers rTeachers = new ReadXmlTeachers();
	ArrayList<Lesson> lessons_list = rLessons.readFile(PATH + "Lessons.xml");
        ArrayList<Teacher> teachers_list = rTeachers.readFile(PATH + "Teachers.xml");
        
        //keys are the id of lessons and values are the lessons themselves
        HashMap<String,Lesson> mapLessons = new HashMap<String,Lesson>();
        //keys are the id of teachers and values are the teachers themselves
        HashMap<String,Teacher> mapTeachers = new HashMap<String,Teacher>();
        
        for (Lesson l: lessons_list) {
            mapLessons.put(l.getId(), l);
            //System.out.println(l.getId());
        }
        for (Teacher t: teachers_list)
            mapTeachers.put(t.getId(), t);
        
        //set teachers to lessons
        for (Teacher t: teachers_list) {
            for (String lessonId: t.getLessons()) {
                String[] teachers = mapLessons.get(lessonId).getTeachers();
                if (teachers == null) {
                    teachers = new String[1];
                    teachers[0] = t.getId();
                    mapLessons.get(lessonId).setTeachers(teachers);
                } else {
                    String[] newTeachers = new String[teachers.length + 1];
                    int i = 0;
                    for (; i < teachers.length; i++)
                        newTeachers[i] = teachers[i];
                    newTeachers[i] = t.getId();
                    mapLessons.get(lessonId).setTeachers(newTeachers);
                }
            }
        }
        
        
        //BestFS algorithm
        Queue<State> queue = new LinkedList<State>();
        queue.add(new State(lessons_list,teachers_list,mapLessons,mapTeachers));
        int hour = 0;
        while (!queue.peek().isOk()) {
            if (hour == 7 || hour == 15 || hour == 23 || hour == 31) {
                hour++;
                continue;
            }
            
            State state = queue.poll();
            System.out.println("Current score = " + state.getScore());
            
            State[] children = state.getChildren((hour++)%Programma_Gymnasio.NUMBER_OF_HOURS);
            if (children != null) {
                for (State child: children) queue.add(child);
            }
            
            Collections.sort((List<State>) queue);
        }
        
        //queue.peek().print();
        queue.peek().writeSchedule();
        System.out.println("Schedule has been written!");
        
        long t2 = System.currentTimeMillis();
        System.out.println("Finished in " + (t2 - t1)/1000.0 + " seconds");
    }
    
}
